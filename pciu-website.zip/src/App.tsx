import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AuthProvider } from "@/contexts/AuthContext";
import Index from "./pages/Index";
import FacultyList from "./pages/FacultyList";
import FacultiesPage from "./pages/FacultiesPage";
import FacultyProfile from "./pages/FacultyProfile";
import Library from "./pages/Library";
import Notices from "./pages/Notices";
import FacultyAuth from "./pages/FacultyAuth";
import FacultyAdmin from "./pages/FacultyAdmin";
import IQAC from "./pages/IQAC";
import DepartmentEnglish from "./pages/DepartmentEnglish";
import DepartmentLaw from "./pages/DepartmentLaw";
import DepartmentJournalism from "./pages/DepartmentJournalism";
import DepartmentCSE from "./pages/DepartmentCSE";
import DepartmentEEE from "./pages/DepartmentEEE";
import DepartmentCivil from "./pages/DepartmentCivil";
import DepartmentTextile from "./pages/DepartmentTextile";
import DepartmentFashion from "./pages/DepartmentFashion";
import DepartmentBBA from "./pages/DepartmentBBA";
import Admission from "./pages/Admission";
import Academics from "./pages/Academics";
import TechStack from "./pages/TechStack";
import AdminAuth from "./pages/AdminAuth";
import AdminDashboard from "./pages/admin/AdminDashboard";
import AdminPages from "./pages/admin/AdminPages";
import PageEditor from "./pages/admin/PageEditor";
import VisualPageEditor from "./pages/admin/VisualPageEditor";
import AdminHomepage from "./pages/admin/AdminHomepage";
import AdminUsers from "./pages/admin/AdminUsers";
import AdminSettings from "./pages/admin/AdminSettings";
import AdminMedia from "./pages/admin/AdminMedia";
import AdminActivity from "./pages/admin/AdminActivity";
import AdminTemplates from "./pages/admin/AdminTemplates";
import AdminFaculty from "./pages/admin/AdminFaculty";
import AdminJournal from "./pages/admin/AdminJournal";
import DynamicPage from "./pages/DynamicPage";
import DesignExport from "./pages/DesignExport";
import VCMessagePage from "./pages/VCMessage";
import Management from "./pages/Management";
import AboutUniversity from "./pages/AboutUniversity";
import PortCityNews from "./pages/PortCityNews";
import NotFound from "./pages/NotFound";
import ManagedPageRoute from "./components/cms/ManagedPageRoute";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <AuthProvider>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<Index />} />
            <Route path="/library" element={<ManagedPageRoute slug="library" fallback={Library} />} />
            <Route path="/notices" element={<ManagedPageRoute slug="notices" fallback={Notices} />} />
            <Route path="/faculty" element={<ManagedPageRoute slug="faculty" fallback={FacultyList} />} />
            <Route path="/faculties" element={<FacultiesPage />} />
            <Route path="/faculty/:id" element={<FacultyProfile />} />
            <Route path="/faculty-auth" element={<FacultyAuth />} />
            <Route path="/faculty-admin" element={<FacultyAdmin />} />
            <Route path="/iqac" element={<ManagedPageRoute slug="iqac" fallback={IQAC} />} />
            <Route path="/department/english" element={<ManagedPageRoute slug="department-english" fallback={DepartmentEnglish} />} />
            <Route path="/department/law" element={<ManagedPageRoute slug="department-law" fallback={DepartmentLaw} />} />
            <Route path="/department/journalism" element={<ManagedPageRoute slug="department-journalism" fallback={DepartmentJournalism} />} />
            <Route path="/department/cse" element={<ManagedPageRoute slug="department-cse" fallback={DepartmentCSE} />} />
            <Route path="/department/eee" element={<ManagedPageRoute slug="department-eee" fallback={DepartmentEEE} />} />
            <Route path="/department/civil" element={<ManagedPageRoute slug="department-civil" fallback={DepartmentCivil} />} />
            <Route path="/department/textile" element={<ManagedPageRoute slug="department-textile" fallback={DepartmentTextile} />} />
            <Route path="/department/fashion" element={<ManagedPageRoute slug="department-fashion" fallback={DepartmentFashion} />} />
            <Route path="/department/bba" element={<DepartmentBBA />} />
            <Route path="/admission" element={<Admission />} />
            <Route path="/academics" element={<Academics />} />
            <Route path="/tech-stack" element={<TechStack />} />
            
            {/* Admin Routes */}
            <Route path="/admin-auth" element={<AdminAuth />} />
            <Route path="/admin" element={<AdminDashboard />} />
            <Route path="/admin/homepage" element={<AdminHomepage />} />
            <Route path="/admin/faculty" element={<AdminFaculty />} />
            <Route path="/admin/pages" element={<AdminPages />} />
            <Route path="/admin/pages/new" element={<PageEditor />} />
            <Route path="/admin/pages/:id" element={<PageEditor />} />
            <Route path="/admin/visual/:id" element={<VisualPageEditor />} />
            <Route path="/admin/users" element={<AdminUsers />} />
            <Route path="/admin/media" element={<AdminMedia />} />
            <Route path="/admin/activity" element={<AdminActivity />} />
            <Route path="/admin/templates" element={<AdminTemplates />} />
            <Route path="/admin/settings" element={<AdminSettings />} />
            <Route path="/admin/journal" element={<AdminJournal />} />
            
            {/* Dynamic Pages */}
            <Route path="/page/:slug" element={<DynamicPage />} />
            <Route path="/design-export" element={<DesignExport />} />
            <Route path="/vice-chancellors-message" element={<ManagedPageRoute slug="vice-chancellors-message" fallback={VCMessagePage} />} />
            <Route path="/management" element={<ManagedPageRoute slug="management" fallback={Management} />} />
            <Route path="/about-the-university" element={<AboutUniversity />} />
            <Route path="/port-city-news" element={<PortCityNews />} />
            
            {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
            <Route path="*" element={<NotFound />} />
          </Routes>
        </BrowserRouter>
      </TooltipProvider>
    </AuthProvider>
  </QueryClientProvider>
);

export default App;
